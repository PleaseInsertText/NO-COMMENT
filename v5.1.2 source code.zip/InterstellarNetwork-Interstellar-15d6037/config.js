const config = {
  challenge: false,
  users: {
    // username: 'password', you can add multiple users.
    interstellar: 'password',
  },
}
export default config
